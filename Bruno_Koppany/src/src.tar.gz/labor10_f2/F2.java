package labor10_f2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JFrame;

import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.OSMTileFactoryInfo;
import org.jxmapviewer.viewer.DefaultTileFactory;
import org.jxmapviewer.viewer.DefaultWaypoint;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.TileFactoryInfo;
import org.jxmapviewer.viewer.Waypoint;
import org.jxmapviewer.viewer.WaypointPainter;
import org.jxmapviewer.painter.CompoundPainter;
import org.jxmapviewer.painter.Painter;

import java.io.FileInputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.awt.geom.Point2D;

/**
 * A simple sample application that shows a OSM map of Europe containing a route
 * with waypoints
 * 
 * @author Martin Steiger
 */
public class F2 {
	public static ArrayList<Point2D.Double> al1;
	public static ArrayList<Point2D> al2;
	public static ArrayList<Point2D> al3;
	public static ArrayList<String> strList;
	public static ArrayList<GeoPosition> track;
	public static Set<Waypoint> waypoints;

	public static <T> void main(String[] args) {
		al1 = new ArrayList<Point2D.Double>();
		al2 = new ArrayList<Point2D>();
		al3 = new ArrayList<Point2D>();
		strList = new ArrayList<String>();
		track = new ArrayList<GeoPosition>();
		waypoints = new HashSet<Waypoint>();
		JXMapViewer mapViewer = new JXMapViewer();

		// Display the viewer in a JFrame
		JFrame frame = new JFrame("JXMapviewer2 Összes busz megállói");
		frame.getContentPane().add(mapViewer);
		frame.setSize(800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

		// Create a TileFactoryInfo for OpenStreetMap
		TileFactoryInfo info = new OSMTileFactoryInfo();
		DefaultTileFactory tileFactory = new DefaultTileFactory(info);
		tileFactory.setThreadPoolSize(8);
		mapViewer.setTileFactory(tileFactory);

		System.out.println(args[0]);

		try {
			readFile(args[0]);
		} catch (Exception e) {
		}

		calcWaypoints();
		setTrack();

		RoutePainter routePainter = new RoutePainter(track);
		
		// Set the focus
		mapViewer.zoomToBestFit(new HashSet<GeoPosition>(track), 1);

		// Create a waypoint painter that takes all the waypoints
		WaypointPainter<Waypoint> waypointPainter = new WaypointPainter<Waypoint>();
		waypointPainter.setWaypoints(waypoints);

		// Create a compound painter that uses both the route-painter and the
		// waypoint-painter
		List<Painter<JXMapViewer>> painters = new ArrayList<Painter<JXMapViewer>>();
		 painters.add(routePainter);
		painters.add(waypointPainter);

		CompoundPainter<JXMapViewer> painter = new CompoundPainter<JXMapViewer>(
				painters);

		mapViewer.setOverlayPainter(painter);

	}

	public static void setTrack() {
		for (int i = 0; i < al1.size(); ++i) {
			// Create a track from the geo-positions
			track.add(new GeoPosition( al1.get(i).x, al1.get(i).y ));
			// Create waypoints from the geo-positions
			waypoints.add(new DefaultWaypoint(track.get(i)));
		}
	}

	public static void calcWaypoints() {
		int x2, y2, x3, y3, i = 0;
		double x = 0, x1, y = 0, y1;
		for (String s : strList) {
			i++;
			if (i % 2 == 0) {
				y = Integer.parseInt(s);
				i = 0;
				x1 = x / 10000000.0;
				y1 = y / 10000000.0;
				al1.add(new Point2D.Double(x1, y1));
				System.out.println(x1);
			}
			x = Integer.parseInt(s);
		}
	}

	// Beolvassa az osszes buszmegallot
	public static void readFile(String fileName) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		try {
			String line = br.readLine();

			while (line != null) {
				strList.add(new String(line));
				System.out.println(line);
				line = br.readLine();
			}
		} finally {
			br.close();
		}
	}
}
